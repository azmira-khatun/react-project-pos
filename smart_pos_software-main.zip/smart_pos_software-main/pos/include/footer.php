<footer class="main-footer bg-dark text-center">
    <div class="float-right d-none d-sm-block">
    </div>
    <strong>Copyright &copy; 2025 <b>DREAM POS</b>.</strong> All rights reserved by <b> Rafia Hawlader </b>.
</footer>

<aside class="control-sidebar control-sidebar-dark"></aside>
</div>

<script src="dist/plugins/jquery/jquery.min.js"></script>
<script src="dist/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="dist/plugins/select2/js/select2.full.min.js"></script>
<script src="dist/js/adminlte.min.js"></script>
<script src="dist/js/demo.js"></script>

<script src="dist/js/create_sale_script.js"></script> 

</body>
</html>